-- ========================================================
-- Charity Donation Impact Visualizer - Supabase Schema
-- ========================================================
-- Run this in your Supabase SQL Editor to provision tables,
-- indexes, row-level security, and test data.

CREATE TABLE IF NOT EXISTS public.donations (
    id TEXT PRIMARY KEY,
    donor_name TEXT NOT NULL,
    donor_email TEXT,
    donor_type TEXT NOT NULL CHECK (donor_type IN ('Individual', 'Corporate', 'Foundation', 'Anonymous')),
    amount NUMERIC(12, 2) NOT NULL CHECK (amount >= 0),
    expense_amount NUMERIC(12, 2) NOT NULL DEFAULT 0 CHECK (expense_amount >= 0),
    date DATE NOT NULL DEFAULT CURRENT_DATE,
    category TEXT NOT NULL CHECK (category IN (
        'Clean Water', 
        'Food & Nutrition', 
        'Healthcare & Medicine', 
        'Education & Literacy', 
        'Disaster Relief', 
        'Shelter & Housing'
    )),
    campaign TEXT NOT NULL,
    beneficiaries_helped INTEGER NOT NULL DEFAULT 0 CHECK (beneficiaries_helped >= 0),
    payment_method TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'Deployed' CHECK (status IN ('Allocated', 'In Progress', 'Deployed')),
    location TEXT,
    notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Optimize search and filtering queries
CREATE INDEX IF NOT EXISTS idx_donations_category ON public.donations(category);
CREATE INDEX IF NOT EXISTS idx_donations_date ON public.donations(date DESC);
CREATE INDEX IF NOT EXISTS idx_donations_status ON public.donations(status);
CREATE INDEX IF NOT EXISTS idx_donations_donor_type ON public.donations(donor_type);

-- Row Level Security (RLS)
ALTER TABLE public.donations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Public Read Access" 
ON public.donations FOR SELECT USING (true);

CREATE POLICY "Full Access For Authorized App" 
ON public.donations FOR ALL USING (true);
