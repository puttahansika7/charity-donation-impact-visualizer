export type DonorType = 'Individual' | 'Corporate' | 'Foundation' | 'Anonymous';

export type CharityCategory = 
  | 'Clean Water'
  | 'Food & Nutrition'
  | 'Healthcare & Medicine'
  | 'Education & Literacy'
  | 'Disaster Relief'
  | 'Shelter & Housing';

export type DonationStatus = 'Allocated' | 'In Progress' | 'Deployed';

export type PaymentMethod = 
  | 'Credit Card' 
  | 'Bank Transfer' 
  | 'Crypto' 
  | 'Payroll Giving' 
  | 'Cheque';

export interface DonationRecord {
  id: string;
  donorName: string;
  donorEmail?: string;
  donorType: DonorType;
  amount: number;
  expenseAmount: number;
  date: string; // YYYY-MM-DD
  category: CharityCategory;
  campaign: string;
  beneficiariesHelped: number;
  paymentMethod: PaymentMethod;
  status: DonationStatus;
  notes?: string;
  location?: string;
  createdAt: string;
  updatedAt: string;
}

export interface CategoryMetric {
  category: CharityCategory;
  totalDonations: number;
  totalExpenses: number;
  totalBeneficiaries: number;
  donationCount: number;
  percentageOfTotal: number;
  color: string;
  bgColor: string;
  textColor: string;
  iconName: string;
}

export interface MonthlyMetric {
  month: string; // e.g. "2026-01"
  label: string; // e.g. "Jan 2026"
  donations: number;
  expenses: number;
  beneficiaries: number;
  netReserve: number;
}

export interface ImpactSummaryStats {
  totalDonations: number;
  totalExpenses: number;
  netReserve: number;
  totalBeneficiaries: number;
  averageDonation: number;
  costPerBeneficiary: number;
  deploymentRate: number; // percentage (expenses / donations)
  recordCount: number;
}

export interface AiInsightResponse {
  summary: string;
  efficiencyScore: number;
  costPerBeneficiary?: string;
  fundDeploymentRate?: string;
  keyFindings: string[];
  strategicRecommendations: string[];
  impactMilestoneNarrative?: string;
  isFallback?: boolean;
}
